<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Backups extends Model
{
    //
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Custorders extends Model
{
    //
}

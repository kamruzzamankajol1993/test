<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sendTransection extends Model
{
    //
}

@include('layouts._head')
<body>
<!-- BEGIN HEADER  -->
@include('layouts._nav')
<!-- END HEADER  -->
<!-- BEGIN CONTENT  -->
@include('layouts._body')
@include('layouts._message')
<!-- END CONTENT  -->
@include('layouts._javascript')
</body>
</html>
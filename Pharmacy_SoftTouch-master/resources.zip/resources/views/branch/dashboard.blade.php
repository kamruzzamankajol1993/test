@extends('layouts.branch-app')
@section('title', '| Dashboard')
@section('content')
<div class="panel panel-default">
        <div class="panel-heading">Branch List</div>
  </div>
@endsection
<!doctype html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Document</title>
    <style>
        body {
           
            
        }
    </style>
</head>
<body>
<div class="header">
    <center><h4>Money Receipt</h4></center>
</div>

<div class="body">
  <div style="">
<ul>
  <li>
    <b>Receiver Name:</b>{{$info->receiver_name}}
  </li>
  
</ul>
</div>



</div>

</body>
</html>
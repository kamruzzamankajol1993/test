<?php

return [

    'sales'     => 'Análisis de ventas',
    'purchases' => 'Análisis compras',
    'cusotmers' => 'Análisis cusotmers',
    'weekly'    => 'Ssemanal',
    'monthly'   => 'Mensual',
    'yearly'    => 'Anual',
    'topd'      => 'Los más vendidos - Hoy',
    'topw'      => 'Los más vendidos - Semanal',
    'topm'      => 'Los más vendidos - Mensual',
    'topy'      => 'Mejor vendedor - Anua',
    'today'     => 'Hoy',
    'now'       => 'Ahora',
    'yesterday' => 'Ayer',

    //purchases
    'last' => 'Las últimas compras',
    'most' => 'La mayor parte del producto en stock',

    //customers
    'lastc' => 'Los últimos clientes',
];

<?php

return  [

    'name'       => 'Nombre',
    'password'   => 'contraseña',
    'email'      => 'E-mail',
    'superadmin' => 'Super administrativo',
    'admin'      => 'Administración',
    'permission' => 'Permiso',
    'created_at' => 'Crear en',
    'updated_at' => 'Actualizar en',
    'control'    => 'Controlar',
    'add'        => 'Añadir nueva cuenta',
    'edit'       => 'Editar a ',
    'create'     => 'Crear una nueva cuenta',
];

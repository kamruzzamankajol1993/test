<?php

return [

    // Discount claculator

    'titlediscount' => 'Calculadora de descuentos',
    'before'        => 'Antes',
    'discount'      => 'Descuento',
    'after'         => 'Después',
    'afterd'        => 'Después del descuento',
    'save'          => 'Guardar',
    'price'         => 'Precio',

    // Note

    'titlenote'     => 'Notas',
    'notename'      => 'Nombre de la nota',
    'note'          => 'La nota',
    'before'        => 'Before',
    'white'         => 'blanco',
    'orange'        => 'naranja',
    'blue'          => 'Azul',
    'black'         => 'negro',
    'yellow'        => 'Amarillo',

    //drug search

    'titledsearch'  => 'Búsqueda de medicamentos',
    'drug'          => 'Nombre del medicamento',

];

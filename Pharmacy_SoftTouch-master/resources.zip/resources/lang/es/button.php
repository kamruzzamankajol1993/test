<?php

return [

    'edit'   => 'Editar',
    'add'    => 'Añadir',
    'create' => 'Crear',
    'update' => 'Actualizar',
    'delete' => 'Borrar',
    'show'   => 'Mostrar',
    'print'  => 'Imprimir',
    'close'  => 'Cerrar',
    'search' => 'Buscar',
    'backup'  => 'Crear nueva copia de seguridad',
    'download' => 'Descargar',
    'Orden'  => 'Commande',
    'backupfiles'  => 'Copia de seguridad de archivos',
    'backupdatabase'  => 'Copia de seguridad',
    'forget' => 'Olvidaste tu contraseña?',
    'login' => 'Iniciar sesión',
    'reset' => 'Enviar contraseña Restablecer enlace',
];

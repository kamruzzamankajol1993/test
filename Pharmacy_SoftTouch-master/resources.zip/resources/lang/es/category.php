<?php

 return array(
     'title'     => 'Categorías',
     'addtitle'  => 'Crear categoría',
     'edittitle' => 'Editar para',
     'addcat'    => 'Añadir nueva categoría',
     'name'      => 'Nombre',
     'date'      => 'Fecha de Creación',
     'control'   => 'Controlar',

 );

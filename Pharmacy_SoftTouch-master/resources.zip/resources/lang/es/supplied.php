<?php
return array(
    'title'    => 'suministrado',
    'addprov'  => 'Add new suministrado',
    'editprov' => 'Editar a',
    'name'     => 'Nombre',
    'address'  => 'Dirección',
    'phone'    => 'Teléfono',
    'fax'      => 'Fax',
    'info'     => 'Información',

);

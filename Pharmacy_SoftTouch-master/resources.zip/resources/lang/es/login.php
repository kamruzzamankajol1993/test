<?php

return [

    //login
    'email'       => 'Dirección de correo electrónico',
    'password'    => 'Contraseña',
    'conpassword' => 'Confirmar contraseña',
    'remember'    => 'Recordarme',
    'title'       => 'Iniciar sesión',
    //forget
    'rest'        => 'Restablecer contraseña',
];

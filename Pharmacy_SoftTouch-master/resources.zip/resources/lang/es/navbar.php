<?php
return array(
    'dashboard' => 'dashboard',
    'products'  => 'Medicinales',
    'manage'    => 'Manejo',
    'outstock'  => 'Sin existencias',
    'sell'      => 'Vender',
    'sales'     => 'Ventas',
    'category'  => 'Categorías',
    'provider'  => 'Suministrado',
    'setting'   => 'Configuración',
    'lt'        => 'Idioma y color',
    'users'     => 'Usuarios',
    'analysis'  => 'Análisis',
    'customers' => 'Clientes',
    'printer'   => 'Factura',
    'tools'     => 'Herramientas',
    'discount'  => 'Calculadora de descuentos',
    'note'      => 'Nota',
    'dsearch'   => 'Búsqueda medicinal',
    'other'     => 'Barcode',
    'account'   => 'Cuenta ',
    'logout'    => 'Cerrar sesión ',
    'backup'  => 'De seguridad',
    'search'    => 'Búsqueda'

);

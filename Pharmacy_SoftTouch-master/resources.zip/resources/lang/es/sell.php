<?php
return array(
    'title'      => 'Vender',
    'orderTitle' => 'Pedido',
    'drugs'      => 'medicamento',
    'bname'      => 'Nombre del medicamento',
    'quantity'   => 'Cantidad',
    'price'      => 'Precio',
    'totalPrice' => 'Precio total',
    'seffect'    => 'Modo de empleo?',
    'sell'       => 'Vender',
    'discount'   => 'Descuento',
    'adiscount'  => 'Después del descuento',
    'print'      => 'Imprimir',

);

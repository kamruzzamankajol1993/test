<?php
return array(
    'id'          => 'ID',
    'title'       => 'Clientes',
    'newcustomers'     => 'Añadir nuevo cliente',
    'editcust'    => 'Editar a',
    'name'        => 'Nombre',
    'customerno'  => 'Cliente no',
    'address'     => 'Dirección',
    'phone'       => 'Teléfono',
    'price'       => 'Precio',
    'description' => 'Descripción',
    'info'        => 'Información',
    'discount'    => 'Descuento',
    'tprice'      => 'Precio total',
    'date'        => 'Fecha',
    'control'     => 'Controlar
',
    'search'      => 'Búsqueda por cliente Nú o nombre',
);

<?php
return array(
    'title'       => 'Ventas',
    'titleShow'   => 'Pedido',
    'invoiceno'   => 'Factura no',
    'products'    => 'Denominación del medicamento',
    'price'       => 'Precio',
    'tprice'      => 'Precio total',
    'discount'    => 'Descuento',
    'description' => 'Descripción',
    'saledate'    => 'Fecha',
    'control'     => 'Controlar',

);

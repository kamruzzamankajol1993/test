<?php
return array(
    'dashboard'       => 'Tablero',
    'analysis'        => 'Ventas de dinero y cantidad de compras dentro de un año',
    'analysisTop'     => 'Producto más vendido
',

    'instock'         => 'en stock
',
    'totalsales'      => 'Ventas',
    'totalpurchases'  => 'Compras',

    'amountmoney'     => 'Monto financiero de las ventas durante los meses del año',
    'amountpurchases' => 'Cantidad financiera de compras durante el año meses',
    'lastcustomer'    => "Últimos clientes",

);

<?php
return array(
    'title'    => 'Account',
    'name'     => 'Name',
    'email'    => 'E-mail',
    'password' => 'Password',
);

<?php

 return array(
     'title'     => 'Categoris',
     'addtitle'  => 'Create category',
     'edittitle' => 'Edit to',
     'addcat'    => 'Add new category',
     'name'      => 'Name',
     'date'      => 'Created date',
     'control'   => 'Control',

 );

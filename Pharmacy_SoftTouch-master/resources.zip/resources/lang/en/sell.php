<?php
return array(
    'title'      => 'POS',
    'orderTitle' => 'Order',
    'drugs'      => 'Medicine',
    'bname'      => 'Medicine name',
    'quantity'   => 'Quantity',
    'price'      => 'Price',
    'totalPrice' => 'Total price',
    'seffect'    => 'How to use it ? ',
    'sell'       => 'Sell',
    'discount'   => 'Discount',
    'adiscount'  => 'After Discount',
    'print'      => 'Print',

);

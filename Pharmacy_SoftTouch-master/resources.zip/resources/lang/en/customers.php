<?php
return array(
    'title'       => 'Customers',
    'newcustomers'     => 'Add new customer',
    'editcust'    => 'Edit to',
    'name'        => 'Name',
    'customerno'  => 'Customer no',
    'address'     => 'Address',
    'phone'       => 'Telephone',
    'price'       => 'Price',
    'description' => 'Description',
    'info'        => 'Info',
    'discount'    => 'Discount',
    'tprice'      => 'Total price',
    'date'        => 'Date added',
    'control'     => 'Control',
    'search'      => 'Search by customer no or name',
);

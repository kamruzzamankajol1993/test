<?php
return array(
    'dashboard'       => 'Dashboard',
    'analysis'        => 'Sales amount & amount of purchases within a years',
    'analysisTop'     => 'Best-selling product',

    'instock'         => 'In-stock',
    'totalsales'      => 'Sales',
    'totalpurchases'  => 'Purchases',

    'amountmoney'     => 'Financial amount of sales during the year months',
    'amountpurchases' => 'Financial amount of purchases during the year months',
    'lastcustomer'    => "Latest Customers",

);

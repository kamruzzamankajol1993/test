<?php

return [

    'edit'   => 'Edit',
    'add'    => 'Add',
    'create' => 'Create',
    'update' => 'Update',
    'delete' => 'Delete',
    'show'   => 'Show',
    'print'  => 'Print',
    'close'  => 'Close',
    'search' => 'Search',
    'order'  => 'order',
    'backupfiles'  => 'Create new backup files',
    'backupdatabase'  => 'Create new backup database',
    'download' => 'Download',
    'backupfiles'  => 'Create new backup files',
    'backupdatabase'  => 'Create new backup database',
    'forget' => 'Forgot Your Password?',
    'login' => 'Login',
    'reset' => 'Send Password Reset Link',
];

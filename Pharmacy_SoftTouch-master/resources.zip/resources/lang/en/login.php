<?php

return [

    //login
    'email'       => 'E-Mail Address',
    'password'    => 'Password',
    'conpassword' => 'Confirm-Password',
    'remember'    => 'Remember Me',
    'title'       => 'Login',
    //forget
    'rest'        => 'Reset Password',
];

<?php

return  [

    'name'       => 'Name',
    'password'   => 'password',
    'email'      => 'E-mail',
    'superadmin' => 'Super admin',
    'admin'      => 'Administrator ',
    'permission' => 'Permission',
    'created_at' => 'Create at',
    'updated_at' => 'Update at',
    'control'    => 'Control',
    'add'        => 'Add new account',
    'edit'       => 'Edit to ',
    'create'     => 'Create new account',
];

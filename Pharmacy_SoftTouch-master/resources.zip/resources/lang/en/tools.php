<?php

return [

    // Discount claculator

    'titlediscount' => 'Discount Calculator',
    'before'        => 'Before',
    'discount'      => 'Discount',
    'after'         => 'After',
    'afterd'        => 'After Discount',
    'save'          => 'You save',
    'price'         => 'Price',

    // Note

    'titlenote'     => 'Notes',
    'notename'      => 'Note name',
    'note'          => 'The note',
    'before'        => 'Before',
    'white'         => 'White',
    'orange'        => 'Orange',
    'blue'          => 'Blue',
    'black'         => 'Black',
    'yellow'        => 'Yellow',

    //drug search

    'titledsearch'  => 'Medicines search',
    'drug'          => 'Medicine name',

];

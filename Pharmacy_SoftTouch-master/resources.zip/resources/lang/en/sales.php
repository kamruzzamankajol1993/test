<?php
return array(
    'title'       => 'Sales',
    'titleShow'   => 'Order',
    'invoiceno'   => 'Invoice no',
    'products'    => 'Medicine name',
    'price'       => 'Price',
    'tprice'      => 'Total price',
    'discount'    => 'Discount',
    'description' => 'Description',
    'saledate'    => 'Date',
    'control'     => 'Control',

);

<?php
return array(
    'dashboard' => 'Dashboard',
    'products'  => 'Medicinals',
    'manage'    => 'Manage',
    'outstock'  => 'Out-stock',
    'sell'      => 'Pos',
    'sales'     => 'Sales',
    'category'  => 'Categories',
    'provider'  => 'Suppliers',
    'setting'   => 'Setting',
    'lt'        => 'Language & Color',
    'users'     => 'Users',
    'customers' => 'Customers',
    'printer'   => 'Invoice',
    'tools'     => 'Tools',
    'analysis'  => 'Analysis',
    'discount'  => 'Discount Calculator',
    'note'      => 'Note',
    'dsearch'   => 'Medicines search',
    'other'     => 'Barcode',
    'account'   => 'Account ',
    'logout'    => 'Logout ',
    'backup'     => 'Backup',

    'search'    => 'Search'

);

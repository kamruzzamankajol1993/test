<?php

return [

    'telephone'   => 'Telephone',
    'email'       => 'E-mail',
    'fax'         => 'Fax',
    'dname'       => 'Medicine name',
    'quantity'    => 'Quantity',
    'price'       => 'Price',
    'tprice'      => 'Total price',
    'saledate'    => 'Date',
    'info'        => 'Information',
    'address'     => 'Address',
    'name'        => 'Name',
    'discount'    => 'Discount',
    'description' => 'Description',
    'barcode'     => 'Barcode',
    'invoiceno'   => 'Invoice No',
    'invoicedate' => 'Invoice Date',
    'customerno'  => 'Customer No',
    'gname'       => 'Genetic name',
    'bname'       => 'Brand Name',
    'idnumber'    => 'Product Number',
    'country'     => 'Country',
    'expire'      => 'Expire date',
    'imdate'      => 'Importer date:',
    'orgprice'    => 'Original price',

];

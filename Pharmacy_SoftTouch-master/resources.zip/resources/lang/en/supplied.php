<?php
return array(
    'title'    => 'Suppliers',
    'addprov'  => 'Add new supplier',
    'editprov' => 'Edit to',
    'name'     => 'Name',
    'address'  => 'Address',
    'phone'    => 'Telephone',
    'fax'      => 'Fax',
    'info'     => 'Info',

);

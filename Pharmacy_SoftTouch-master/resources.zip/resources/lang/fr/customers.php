<?php
return array(
    'id'         => 'ID',
    'title'      => 'les clients',
    'newcustomers'    => 'Ajouter un nouveau fournisseur',
    'editcust'   => 'Modifier à',
    'name'       => 'Nom',
    'customerno' => 'Client Nu',
    'address'    => 'Adresse',
    'phone'      => "Téléphone",
    'price'      => 'Prix',
    'discount'   => 'Remise',
    'fax'        => 'Fax',
    'tprice'     => 'Prix total',
    'info'       => 'Information
',
    'date'       => 'dater ajoutée',
    'control'    => 'Contrôle',
    'search'     => 'Recherche par nom',
);

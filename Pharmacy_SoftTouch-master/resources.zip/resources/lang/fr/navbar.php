<?php
return array(
    'dashboard' => 'Tableau de bord',
    'products'  => 'Médicament',
    'manage'    => 'Gérer',
    'outstock'  => 'En rupture de stock',
    'sell'      => 'Vendre',
    'sales'     => 'Ventes',
    'category'  => 'Catégories',
    'provider'  => 'Fournisseur',
    'setting'   => 'Réglage',
    'customers' => 'Les clients',
    'lt'        => 'Langue et couleur',
    'users'     => 'Utilisateurs
',
    'analysis'  => 'Analyse',
    'printer'   => 'Facture',
    'tools'     => 'Outils',
    'discount'  => "Calculatrice d'escompte",
    'note'      => 'Noter',
    'dsearch'   => 'Recherche médicale',
    'other'     => 'Barcode',
    'about'     => 'E`nviron',
    'account'   => 'Compte ',
    'logout'    => 'Connectez-Out',
    'backup'  => 'copia de seguridad',
    'search'    => 'Recherche'

);

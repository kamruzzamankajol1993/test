<?php
return array(
    'title'       => 'Ventes',
    'titleShow'   => 'Commande',
    'invoiceno'   => 'Facture non',
    'products'    => 'Médicaments',
    'price'       => 'Prix',
    'tprice'      => 'Prix total',
    'discount'    => 'Remise',
    'description' => 'Description',
    'saledate'    => 'Date de vente',
    'control'     => 'Contrôle',

);

<?php
return array(
    'title'    => 'Fournisseur',
    'addprov'  => 'Ajouter un nouveau fournisseur',
    'editprov' => 'Modifier à',
    'name'     => 'Nom',
    'address'  => 'Adresse',
    'phone'    => "Téléphone",
    'fax'      => 'Fax',
    'info'     => 'Info',
    'delete'   => 'Effacer',
    'edit'     => 'Modifier',

);

<?php

return  [

    'name'       => 'Nom',
    'password'   => 'Mot de passe',
    'email'      => 'E-mail',
    'superadmin' => 'Super admin',
    'admin'      => 'Administrateur ',
    'permission' =>  'Autorisation',
    'created_at' => 'Créer à',
    'updated_at' => 'Mise à jour à
',
    'control'    => 'Contrôle',
    'add'        => 'Ajouter un nouveau compte',
    'edit'       => 'Modifier à
',
    'create'     => 'Créer un nouveau compte',
];

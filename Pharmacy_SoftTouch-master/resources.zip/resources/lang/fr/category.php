<?php

return array(
    'title'       => 'Catégorie',
    'addtitle'    => 'Créer une catégorie',
    'edittitle'   => 'Modifier pour',
    'addcat'      => 'Ajouter nouvelle catégorie',
    'id'          => 'ID',
    'customerno'  => 'Client non',
    'name'        => 'Nom',
    'description' => 'La description',
    'info'        => 'Info',
    'discount'    => 'Remise',
    'tprice'      => 'Prix total',
    'date'        => 'Date de création',
    'control'     => 'Contrôle',
    'delete'      => 'Supprimer',
    'edit'        => 'modifier',

);

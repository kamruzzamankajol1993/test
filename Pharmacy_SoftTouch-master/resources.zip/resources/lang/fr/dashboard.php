<?php
return array(
    'dashboard'       => 'tableau de bord',
    'analysis'        => 'L argent des ventes et le Prix des achats dans les années',
    'analysisTop'     => 'Médicaments les plus vendus',

    'instock'         => 'Total des médicaments en stock',
    'totalsales'      => 'Ventes totales',
    'totalpurchases'  => 'Total des achats',

    'amountmoney'     => "Prix financier des ventes au cours de l'année mois",
    'amountpurchases' => "Prix financier des achats au cours de l'année mois",
    'lastcustomer'    => "Dernier client",
);

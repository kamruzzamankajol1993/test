<?php

return [

    //login
    'email'       => 'E-Mail Address',
    'password'    => 'Mot de passe',
    'conpassword' => 'Confirmer le mot de passe',
    'remember'    => 'Se souvenir de moi',
    'title'       => 'Connexion
',
    //forget
    'rest'        => 'Réinitialiser le mot de passe',
];

<?php

return [

    // Discount claculator

    'titlediscount' => "Calculatrice d'escompte",
    'before'        => 'Avant',
    'discount'      => 'Remise',
    'after'         => 'Après',
    'afterd'        => 'Après remise',
    'save'          => 'Vous sauvegardez',
    'price'         => 'Prix',
    // Note

    'titlenote'     => 'Noter',
    'notename'      => 'Nom de la note',
    'note'          => 'La note',
    'white'         => 'Blanc',
    'orange'        => 'Orangé',
    'blue'          => 'Bleu',
    'black'         => 'Noir',
    'yellow'        => 'Jaune',
    'add'           => 'Ajouter',
    'edit'          => 'Modifier',

    //drug search

    'titledsearch'  => 'Recherche de médicament',
    'drug'          => 'Nom du médicament',
    'search'        => 'Recherche',

];

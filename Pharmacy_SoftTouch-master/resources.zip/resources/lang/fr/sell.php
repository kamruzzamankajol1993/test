<?php
return array(
    'title'      => 'Vendre des médicaments',
    'orderTitle' => 'Commande',
    'drugs'      => 'Médicaments',
    'bname'      => 'Nom de médicament',
    'quantity'   => 'Quantité',
    'price'      => 'Prix',
    'totalPrice' => 'Prix Total',
    'seffect'    => "Comment l'utiliser?",
    'sell'       => 'Vendre',
    'discount'   => 'Remise',
    'adiscount'  => 'Après remise',
    'print'      => 'imprimante',

);

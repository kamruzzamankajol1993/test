<?php

return [

    'edit'   => 'Modifier',
    'add'    => 'Ajouter',
    'create' => 'Créer',
    'update' => 'Mettre à jour',
    'delete' => 'Supprimer',
    'show'   => 'Montrer',
    'print'  => 'Imprimer',
    'close'  => 'Fermer',
    'search' => 'Rechercher',
    'backup'  => 'Créer une nouvelle sauvegarde',
    'download' => 'Télécharger',
    'forget' => 'Oublié votre mot de passe?',
    'order'  => 'Commande',
    'backupfiles'  => 'Sauvegarde de fichiers',
    'backupdatabase'  => 'Sauvegarde de base de données',
    'login' => 'Connexion',
    'reset' => 'Envoyer le lien de réinitialisation du mot de passe
',
];

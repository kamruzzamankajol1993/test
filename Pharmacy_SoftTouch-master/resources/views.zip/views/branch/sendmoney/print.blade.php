<!doctype html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Document</title>
    <style>
        body {
           
            
        }
    </style>
</head>
<body>
<div class="header">
    <center><h4>Money Receipt</h4></center>
</div>

<div class="body">
  <div style="">
<ul>
  <li>
    <b>Sender Name:</b>{{$info->sender_name}}
  </li>
  
</ul>
</div>



</div>
<br><br>
<div class="sign">
    <div style="float:left;"><u>Prepared by</u></div>
     <div style="float:left;margin-left:500px;"><u>Customer</u></div>
</div>
</body>
</html>
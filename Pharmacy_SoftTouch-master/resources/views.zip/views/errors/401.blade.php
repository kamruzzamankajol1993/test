@extends('layouts.app')
@section('title', '| Show')

@section('content')
    <div class="text-center">
        <h3><i class="fa fa-lock fa-5x" aria-hidden="true"></i></h3>
        <h1>Access Denied</h1>
        <h4>This page is only allowed for <u>super admin</u></h4>
    </div>
@endsection

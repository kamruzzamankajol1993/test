<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Brian2694\Toastr\Facades\Toastr;
use DB;
use PDF;
use App\Branch;
use App\Receivemoney;
use App\Sendmoney;
use App\Location;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Session;
class SubuserController extends Controller
{
     public function store(Request $request){
        $customer = new Branch();
        $customer->user_id = $request->user_id;
        $customer->sub_branch_id = $request->sub_branch_id;
        $customer->detail = $request->detail;
        $customer->branch_id = str_slug($request->detail);
        $customer->email = $request->email;
        $customer->phone = $request->phone;
        $customer->add= Session::get('customerAddress');;
        $customer->add_by = 1;
        
        $customer->password = Hash::make($request->password);
        $customer->mpass =$request->password;
        $customer->save();

        //$customerId = $customer->id;
        //Session::put('customerId',$customerId);
        //Session::put('customerName',$customer->branch_id);
        //Session::put('customerAddress',$customer->add);
   //Session::put('customerStatus',$customer->add_by);
       return redirect('/sub_user');
    }

    public function index(){

    	$details= Branch::latest()->paginate(10);
        
    	return view('subuser.manage',['details'=>$details]);
    }


    public function create(){

    	return view('subuser.create');
    }

     public function destroy($id)
    {
         Branch::find($id)->delete();
         Toastr::warning('Successfully Deleted :)','Success');
         return redirect()->back();
    }


    public function edit($id)
    {
        $detail = Branch::find($id);
        return view('subuser.edit',['detail'=>$detail]);
    }


   public function update(Request $request){
    	 $userId = $request->input('id');

    	$customer = Branch::find($userId );
        $customer->user_id = $request->user_id;
        $customer->detail = $request->detail;
        $customer->branch_id = str_slug($request->detail);
        $customer->email = $request->email;
        $customer->phone = $request->phone;
        $customer->add = $request->add;
        $customer->add_by = $request->add_by;
        $customer->sub_branch_id = $customer->id;
        $customer->password = Hash::make($request->password);
        $customer->password = $request->password;
        $customer->save();
   	     return redirect('/sub_user')->with('message','Updated Successfully');
    }


     public function history($add)
    {
        $details = Sendmoney::where('branch_id',$add)->get();
        $details1 = Receivemoney::where('branch_id',$add)->get();
        return view('subuser.history',['details'=>$details,'details1'=>$details1]);
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Brian2694\Toastr\Facades\Toastr;
use DB;
use PDF;
use App\Branch;
use App\Receivemoney;
use App\Location;
use App\Money;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Session;
class SubBranchController extends Controller
{
    public function index(){

    	$details=Money::latest()->paginate(10);
        
    	return view('subbranch.manage',['details'=>$details]);
    }


    public function create(){

    	return view('subbranch.create');
    }


    public function store(Request $request){
        $customer = new Money();
        $customer->user_id = $request->user_id;
        $customer->sender_name = $request->sender_name;
        $customer->sender_nid = $request->sender_nid;
        $customer->sender_number = $request->sender_number;
        $customer->receiver_name = $request->receiver_name;
        $customer->receiver_number = $request->receiver_number;
        $customer->receiver_nid = $request->receiver_nid;
        $customer->save();

        //$customerId = $customer->id;
        //Session::put('customerId',$customerId);
        //Session::put('customerName',$customer->branch_id);

       return redirect('/sub_branch');
    }


     public function destroy($id)
    {
         Money::find($id)->delete();
         Toastr::warning('Successfully Deleted :)','Success');
         return redirect()->back();
    }


     public function edit($id)
    {
        $detail = Money::find($id);
        return view('subbranch.edit',['detail'=>$detail]);
    }


   public function update(Request $request){
   	    $userId = $request->input('id');

    	$customer =Money::find($userId );
        $customer->user_id = $request->user_id;
        $customer->sender_name = $request->sender_name;
        $customer->sender_nid = $request->sender_nid;
        $customer->sender_number = $request->sender_number;
        $customer->receiver_name = $request->receiver_name;
        $customer->receiver_number = $request->receiver_number;
        $customer->receiver_nid = $request->receiver_nid;
        $customer->save();
   	     return redirect('/sub_branch')->with('message','Updated Successfully');
    }
}

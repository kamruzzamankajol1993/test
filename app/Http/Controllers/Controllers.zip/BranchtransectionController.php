<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Brian2694\Toastr\Facades\Toastr;
use DB;
use PDF;
use App\Sendmoney;
use App\Branch;
use App\Money;
use App\Receivemoney;
use App\Location;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Session;
class BranchtransectionController extends Controller
{
    public function index(){

    	$details=Sendmoney::latest()->get();
       $bName =Branch::select('add')->get();  
    	return view('branch.sendmoney.manage',['bName'=>$bName,'details'=>$details]);
    }


    public function search(Request $request)
    {
        
        $search_txt = $request->input('from');
        $details =Money::Where('sender_number', 'like', '%'.$search_txt.'%')
                 ->orwhere('sender_nid', 'like', '%'.$search_txt.'%')
                 ->get();
       
   $bName =DB::table('branches')->distinct('add')->get(['add']);

    return view('branch.sendmoney.search')->with([
       
     'details'=>$details,
    'bName'=>$bName
    ]);
    }


     public function store(Request $request){

         if($request->get('submit') == 'btn1') {

    
        $this->validate($request,[
            
            'sender_name' => 'required',
            'sender_number' => 'required',
            'sender_location' => 'required',
            'amount' => 'required',
            'receiver_location' => 'required',
            'receiver_name' => 'required'
            
        ]);
        date_default_timezone_set('Asia/Dhaka');
        $currentDate = date("h:i:s",time());
        $newDate =date('Y-m-d');
        $reg = new Sendmoney();
        $reg->cost = $request->cost;
        $reg->pin = 'ATC-'.rand('10000000','99999999');
        $reg->sender_name = $request->sender_name;
        $reg->sender_number = $request->sender_number;
        $reg->sender_location = $request->sender_location;
        $reg->sender_nid = $request->sender_nid;
        $reg->amount = $request->amount;
        $reg->status = "unpaid";
        $reg->receiver_location = $request->receiver_location;
        $reg->receiver_name = $request->receiver_name;
        $reg->receiver_nid = $request->receiver_nid;
        $reg->date=$newDate;
        $reg->time= $currentDate;
        $reg->branch_id = Session::get('customerId');
        $reg->save();
        $regPin=$reg->pin;

        $rec = new Receivemoney();
        $rec->cost = $request->cost;
        $rec->pin = $regPin;
        $rec->sender_name = $request->sender_name;
        $rec->sender_number = $request->sender_number;
        $rec->sender_location = $request->sender_location;
        $rec->sender_nid = $request->sender_nid;
        $rec->amount = $request->amount;
        $rec->status = "unpaid";
        $rec->receiver_location = $request->receiver_location;
        $rec->receiver_name = $request->receiver_name;
        $rec->receiver_nid = $request->receiver_nid;
        $rec->date=$newDate;
        $rec->time= $currentDate;
        $rec->branch_id = Session::get('customerId');
        $rec->save();
        Toastr::success('Successfully Saved :)' ,'Success');
        return redirect()->route('branch.sendmoney');

  } elseif($request->get('submit') == 'btn2') {

     $this->validate($request,[
            
            'sender_name' => 'required',
            'sender_number' => 'required',
            'sender_location' => 'required',
            'amount' => 'required',
            'receiver_location' => 'required',
            'receiver_name' => 'required'
            
        ]);
        date_default_timezone_set('Asia/Dhaka');
        $currentDate = date("h:i:s",time());
        $newDate =date('Y-m-d');
        $reg = new Sendmoney();
        $reg->cost = $request->cost;
        $reg->pin = 'ATC-'.rand('10000000','99999999');
        $reg->sender_name = $request->sender_name;
        $reg->sender_number = $request->sender_number;
        $reg->sender_location = $request->sender_location;
        $reg->sender_nid = $request->sender_nid;
        $reg->amount = $request->amount;
        $reg->status = 2;
        $reg->receiver_location = $request->receiver_location;
        $reg->receiver_name = $request->receiver_name;
        $reg->receiver_nid = $request->receiver_nid;
        $reg->date=$newDate;
        $reg->time= $currentDate;
        $reg->branch_id = Session::get('customerId');
        $reg->save();
        $regPin=$reg->pin;


             $info=Sendmoney::Where('pin',$regPin)->first();
             $pdf=PDF::loadView('branch.sendmoney.print',['info'=>$info]);

            return $pdf->stream('Money_receipt.pdf');

  }

    }


    public function indexreceive(){

        $details=Receivemoney::where('status',1)->latest()->get();
    	return view('branch.receivemoney.manage',['details'=>$details]);
    }


    public function searchreceive(Request $request)
    {
        $search_txt = $request->input('from');
       
         
        $details =Receivemoney::Where('pin', 'like', '%'.$search_txt.'%')
                 ->orwhere('receiver_location', 'like', '%'.$search_txt.'%')
                 ->get();
       
  

    return view('branch.receivemoney.search')->with([
       
     'details'=>$details
   
    ]);
    }


    public function updatereceive(Request $request){
         date_default_timezone_set('Asia/Dhaka');
        $currentDate = date("h:i:s",time());
        $newDate =date('Y-m-d');
        $userId = $request->input('id');
        $rec = Receivemoney::find($userId);
        $rec->pin = $request->pin;
        $rec->sender_name = $request->sender_name;
        $rec->sender_number = $request->sender_number;
        $rec->sender_location = $request->sender_location;
        $rec->branch_id = Session::get('customerId');
        $rec->amount = $request->amount;
        $rec->status =1;
        $rec->receiver_number = $request->receiver_number;
        $rec->receiver_name = $request->receiver_name;
        $rec->receiver_nid = $request->receiver_nid;
        $rec->date=$newDate;
        $rec->time= $currentDate;
         if ($request->file('file')) {
            $photoName = time() . '.' . $request->file->getClientOriginalExtension();
            $request->file->move(public_path().'/upload', $photoName);
            $rec->nidcopy = $photoName;
        }

        $rec->save();
        $pinNum=$rec->pin;
        $sendMoney = DB::table('sendmoneys')->where('pin',$pinNum)->update(['status'=>1]);

             $info=Receivemoney::Where('pin',$pinNum)->first();
             $pdf=PDF::loadView('branch.receivemoney.print',['info'=>$info]);

            return $pdf->stream('Money_receipt.pdf');
       
         //Toastr::success('Successfull:)','Success');
        //return redirect()->route('branch.receivemoney');
     
    }

     public function updatereceivestatus(Request $request){
        $userId = $request->input('id');
        $rec = Receivemoney::find($userId);
        $rec->status = $request->status;
        $rec->save();
        Toastr::success('Successfull:)','Success');
        return redirect()->route('branch.receivemoney');
     }



        public function edit($id){
       
        $prov=Sendmoney::find($id);
        return view('branch.sendmoney.edit',['prov'=>$prov]);

    }

    public function update(Request $request){

date_default_timezone_set('Asia/Dhaka');
        $currentDate = date("h:i:s",time());
        $newDate =date('Y-m-d');
        $rec = new Receivemoney();
        $rec->cost = $request->cost;
        $rec->pin = $request->pin;
        $rec->sender_name = $request->sender_name;
        $rec->sender_number = $request->sender_number;
        $rec->sender_location = $request->sender_location;
        $rec->sender_nid = $request->sender_nid;
        $rec->amount = $request->amount;
        $rec->status = "unpaid";
        $rec->receiver_location = $request->receiver_location;
        $rec->receiver_name = $request->receiver_name;
        $rec->receiver_nid = $request->receiver_nid;
        $rec->date=$newDate;
        $rec->time= $currentDate;
        $rec->branch_id = Session::get('customerId');
        $rec->save();
        $sendMoney = DB::table('sendmoneys')->where('receiver_nid',$request->receiver_nid)->update(['status'=>"unpaid"]);
        Toastr::success('Successfully Saved :)' ,'Success');
        return redirect()->route('branch.sendmoney');

    }
}
